const {chromium}=require('/tmp/cindy-6568-profile-validation/node_modules/playwright-core');
const fs=require('node:fs');const assert=require('node:assert/strict');
const out='/tmp/cindy-6568-evidence';
(async()=>{const b=await chromium.connectOverCDP('http://127.0.0.1:9658');try{
 const p=b.contexts()[0].pages().find(p=>new URL(p.url()).search==='');p.setDefaultTimeout(12000);
 const original=fs.readFileSync(out+'/baseline-personality.txt','utf8');
 if(await p.getByRole('textbox',{name:'性格与说话习惯',exact:true}).isVisible()){await p.getByRole('textbox',{name:'性格与说话习惯',exact:true}).fill(original);await p.getByRole('textbox',{name:'性格与说话习惯',exact:true}).blur();}
 if(await p.getByRole('button',{name:'关闭',exact:true}).count()){await p.getByRole('button',{name:'关闭',exact:true}).click();await p.getByRole('button',{name:'关闭',exact:true}).waitFor({state:'hidden'});}
 await p.evaluate(()=>localStorage.setItem('theme','light'));await p.reload();
 await p.getByRole('button',{name:'设置',exact:true}).click();
 await p.getByRole('button',{name:'性格与说话习惯',exact:true}).click();
 const field=p.getByRole('textbox',{name:'性格与说话习惯',exact:true});
 const long=original+'\n'+'复现测试：请保持简洁清晰。\n'.repeat(900);
 await field.fill(long);
 await p.getByText('超出 868，请缩短后再保存。输入已保留。',{exact:true}).waitFor();
 assert.equal(await field.inputValue(),long);assert.equal(await field.getAttribute('aria-invalid'),'true');
 assert.equal(await p.getByRole('button',{name:'重新保存',exact:true}).count(),0);
 await p.screenshot({path:out+'/after-limit-light.png'});
 // Blur/close must keep the invalid text and focus the field for correction.
 await p.getByRole('button',{name:'关闭',exact:true}).click();
 assert.equal(await field.inputValue(),long);assert(await field.evaluate(e=>document.activeElement===e));
 // Correct the same draft; real debounce -> IPC -> DB -> saved status.
 const corrected='验收：用简洁、清楚的语言回答。需要更多信息时先指出缺少什么。';
 await field.fill(corrected);await p.getByText('已保存',{exact:true}).waitFor();
 await p.screenshot({path:out+'/after-saved-light.png'});
 await p.getByRole('button',{name:'关闭',exact:true}).click();await field.waitFor({state:'hidden'});
 await p.getByRole('button',{name:'设置',exact:true}).click();await p.getByRole('button',{name:'性格与说话习惯',exact:true}).click();
 assert.equal(await field.inputValue(),corrected);
 await p.screenshot({path:out+'/after-reopened-light.png'});
 const boundaryResults=[];
 for(const n of [11999,12000,12001]){
   const input='文'.repeat(n-2)+'😀';await field.fill(' \n'+input+'\n ');
   if(n<=12000){await p.getByText('已保存',{exact:true}).waitFor();await p.getByRole('button',{name:'关闭',exact:true}).click();await field.waitFor({state:'hidden'});await p.getByRole('button',{name:'设置',exact:true}).click();await p.getByRole('button',{name:'性格与说话习惯',exact:true}).click();assert.equal(await field.inputValue(),input);}
   else{await p.getByText('超出 1，请缩短后再保存。输入已保留。',{exact:true}).waitFor();assert.equal(await field.inputValue(),' \n'+input+'\n ');}
   boundaryResults.push({utf16Length:n,outerWhitespace:4,emoji:true,result:n<=12000?'saved and reopened':'blocked, full input retained'});
 }
 await field.fill(original);await p.getByText('已保存',{exact:true}).waitFor();await p.getByRole('button',{name:'关闭',exact:true}).click();await field.waitFor({state:'hidden'});
 await p.evaluate(()=>localStorage.setItem('theme','dark'));await p.reload();
 await p.getByRole('button',{name:'设置',exact:true}).click();await p.getByRole('button',{name:'性格与说话习惯',exact:true}).click();
 await field.fill(long);await p.getByText('超出 868，请缩短后再保存。输入已保留。',{exact:true}).waitFor();
 assert(await p.evaluate(()=>document.documentElement.classList.contains('dark')));
 await p.screenshot({path:out+'/after-limit-dark.png'});
 await field.fill(original);await field.blur();await p.getByRole('button',{name:'关闭',exact:true}).click();await field.waitFor({state:'hidden'});
 await p.getByRole('button',{name:'设置',exact:true}).click();await p.getByRole('button',{name:'资料',exact:true}).click();
 const name=p.getByRole('textbox',{name:'名字',exact:true});console.log('basic labels',await p.locator('input').evaluateAll(es=>es.map(e=>({label:e.getAttribute('aria-label'),value:e.value}))));
 fs.writeFileSync(out+'/verification.json',JSON.stringify({time:new Date().toISOString(),correctedSavedAndReopened:true,boundaryResults,lightAndDark:true,invalidCloseFocus:true},null,2));
 console.log('Verification passed; personality restored.');
}finally{await b.close()}})().catch(e=>{console.error(e);process.exitCode=1});
