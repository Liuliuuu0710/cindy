const {chromium}=require('/tmp/cindy-6568-profile-validation/node_modules/playwright-core');const fs=require('node:fs');const assert=require('node:assert/strict');
const out='/tmp/cindy-6568-evidence';const root='/tmp/cindy-6568-profile-validation/apps/desktop/src/renderer/i18n/locales';
(async()=>{const b=await chromium.connectOverCDP('http://127.0.0.1:9658');try{
const p=b.contexts()[0].pages().find(p=>new URL(p.url()).search==='');p.setDefaultTimeout(10000);const original=fs.readFileSync(out+'/baseline-personality.txt','utf8');const base=p.url().split('?settings')[0];
const results=[];
for(const locale of ['zh-CN','en','zh-TW','ja','ko']){
 const d=JSON.parse(fs.readFileSync(root+'/'+locale+'/common.json'));
 for(const theme of ['light','dark']){
  await p.evaluate(({locale,theme})=>{localStorage.setItem('language',locale);localStorage.setItem('theme',theme)},{locale,theme});
  await p.goto(base+'?settings=1');await p.reload();await p.setViewportSize({width:960,height:720});
  await p.getByRole('button',{name:d.bots.profile.personality,exact:true}).click();const f=p.getByRole('textbox',{name:d.bots.profile.personality,exact:true});
  await f.fill(original+'\n'+'复现测试：请保持简洁清晰。\n'.repeat(900));await p.locator('textarea[aria-invalid="true"]').waitFor();
  await p.waitForFunction(()=>document.documentElement.getAttribute('data-splash-active')!=='true');await p.getByText(d.splash.tips.waking,{exact:true}).waitFor({state:'hidden',timeout:30000});await p.screenshot({path:out+'/locale-'+locale+'-'+theme+'.png'});
  const metrics=await p.evaluate(()=>({lang:document.documentElement.lang,dark:document.documentElement.classList.contains('dark'),width:innerWidth,scrollWidth:document.documentElement.scrollWidth,untranslated:/bots\.autosave\./.test(document.body.innerText)}));assert.equal(metrics.untranslated,false);assert.equal(metrics.dark,theme==='dark');assert(metrics.scrollWidth<=metrics.width);
  results.push({locale,theme,...metrics});await f.fill(original);await f.blur();
 }
}
await p.evaluate(()=>{localStorage.setItem('language','zh-CN');localStorage.setItem('theme','light')});await p.goto(base);await p.reload();await p.setViewportSize({width:1280,height:800});
fs.writeFileSync(out+'/visual-verification.json',JSON.stringify({time:new Date().toISOString(),basicProfileOverlimits:true,scenarios:results},null,2));console.log('Passed profile errors + 10 real Desktop language/theme views at 960×720.');
}finally{await b.close()}})().catch(e=>{console.error(e);process.exitCode=1});
